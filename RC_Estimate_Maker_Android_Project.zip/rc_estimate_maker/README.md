# RC Estimate Maker — Android source project

Native Android Studio starter project for **Rohit Computers – Estimate Maker**.

## Included
- Supplied memo artwork used as a locked background, with the heading changed to **ESTIMATE**.
- Editable serial number, date, customer name, particulars, quantity, rate, amount and total.
- Amount can be typed manually; when left blank it is calculated as quantity × rate.
- Grand total updates automatically from line amounts.
- Add/remove product rows.
- Generates a PDF in `Documents/Rohit Computers`.

## Build APK
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Allow Gradle sync to download the Android/Kotlin dependencies.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio creates `app/build/outputs/apk/debug/app-debug.apk`.

## Current status
This ZIP contains the Android source project and template image; it is **not a compiled APK**. The current execution environment does not have the Android SDK/Gradle build setup needed to compile and test an APK. PDF overlay placement is an initial calibration based on the supplied photo and should be checked with a sample print.
