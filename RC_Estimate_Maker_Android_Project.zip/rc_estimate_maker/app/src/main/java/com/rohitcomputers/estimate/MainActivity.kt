package com.rohitcomputers.estimate

import android.app.Activity
import android.content.ContentValues
import android.graphics.BitmapFactory\nimport android.graphics.Matrix\nimport android.graphics.Paint\nimport android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min

data class ProductRow(
    val particulars: String = "",
    val qty: String = "1",
    val rate: String = "",
    val amountText: String = ""
) {
    // Amount can be typed manually; if left blank it is calculated from Qty × Rate.
    fun amount(): Double = amountText.toDoubleOrNull()
        ?: ((qty.toDoubleOrNull() ?: 0.0) * (rate.toDoubleOrNull() ?: 0.0))
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EstimateScreen() }
    }
}

@Composable
fun EstimateScreen() {
    val context = LocalContext.current
    var serial by remember { mutableStateOf("169") }
    var date by remember { mutableStateOf(SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())) }
    var customer by remember { mutableStateOf("") }
    var rows by remember { mutableStateOf(listOf(ProductRow())) }
    val total = rows.sumOf { it.amount() }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("RC ESTIMATE MAKER", fontWeight = FontWeight.Bold) },
                    backgroundColor = ComposeColor(0xFF111111),
                    contentColor = ComposeColor.White
                )
            },
            backgroundColor = ComposeColor(0xFFF4F4F4)
        ) { pad ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(pad).padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Card(elevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("ESTIMATE DETAILS", fontWeight = FontWeight.Bold)
                            OutlinedTextField(serial, { serial = it }, label = { Text("Serial No.") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(date, { date = it }, label = { Text("Date") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(customer, { customer = it }, label = { Text("Customer / M/s.") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        }
                    }
                }
                item { Text("PRODUCTS", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                itemsIndexed(rows) { index, row ->
                    Card(elevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("Item ${index + 1}", fontWeight = FontWeight.Bold)
                                TextButton(onClick = {
                                    if (rows.size > 1) rows = rows.toMutableList().also { it.removeAt(index) }
                                }) { Text("Remove") }
                            }
                            OutlinedTextField(
                                row.particulars,
                                { value -> rows = rows.toMutableList().also { it[index] = row.copy(particulars = value) } },
                                label = { Text("Particulars") }, modifier = Modifier.fillMaxWidth(), singleLine = true
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    row.qty,
                                    { value -> rows = rows.toMutableList().also { it[index] = row.copy(qty = value) } },
                                    label = { Text("Qty.") }, modifier = Modifier.weight(1f),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true
                                )
                                OutlinedTextField(
                                    row.rate,
                                    { value -> rows = rows.toMutableList().also { it[index] = row.copy(rate = value) } },
                                    label = { Text("Rate (₹)") }, modifier = Modifier.weight(1f),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true
                                )
                            }
                            OutlinedTextField(
                                row.amountText,
                                { value -> rows = rows.toMutableList().also { it[index] = row.copy(amountText = value) } },
                                label = { Text("Amount (₹) — editable") }, modifier = Modifier.fillMaxWidth(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true,
                                placeholder = { Text("Blank = Qty × Rate") }
                            )
                            Text("Line total: ₹${"%.2f".format(Locale.US, row.amount())}", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                item {
                    OutlinedButton(
                        onClick = { rows = rows + ProductRow() },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("+ Add Product") }
                }
                item {
                    Card(backgroundColor = ComposeColor(0xFF171717), contentColor = ComposeColor.White, modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("TOTAL", fontWeight = FontWeight.Bold)
                            Text("₹${"%.2f".format(Locale.US, total)}", fontWeight = FontWeight.Bold)
                        }
                    }
                }
                item {
                    Button(
                        onClick = {
                            try {
                                val pdf = createEstimatePdf(context as Activity, serial, date, customer, rows)
                                savePdf(context as Activity, pdf, "RC_Estimate_$serial.pdf")
                            } catch (e: Exception) {
                                Toast.makeText(context, "PDF error: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(backgroundColor = ComposeColor.Black, contentColor = ComposeColor.White)
                    ) { Text("GENERATE & SAVE PDF") }
                    Text(
                        "Fixed shop details and design are locked. Only estimate fields can be edited.",
                        fontSize = 12.sp, color = ComposeColor.DarkGray, modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        }
    }
}

fun createEstimatePdf(
    activity: Activity,
    serial: String,
    date: String,
    customer: String,
    rows: List<ProductRow>
): ByteArray {
    val bitmap = activity.assets.open("estimate_template.png").use { BitmapFactory.decodeStream(it) }
    val doc = PdfDocument()
    val pageW = 595
    val pageH = 842
    val info = PdfDocument.PageInfo.Builder(pageW, pageH, 1).create()
    val page = doc.startPage(info)
    val canvas = page.canvas
    canvas.drawColor(android.graphics.Color.WHITE)

    val scale = min(pageW.toFloat() / bitmap.width, pageH.toFloat() / bitmap.height)
    val drawW = bitmap.width * scale
    val drawH = bitmap.height * scale
    val left = (pageW - drawW) / 2f
    val top = (pageH - drawH) / 2f
    val matrix = Matrix().apply { setScale(scale, scale); postTranslate(left, top) }
    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    canvas.drawBitmap(bitmap, matrix, paint)

    fun x(px: Float) = left + px * scale
    fun y(py: Float) = top + py * scale
    fun text(value: String, px: Float, py: Float, size: Float, align: Paint.Align = Paint.Align.LEFT) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.BLACK
            textSize = size * scale
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            textAlign = align
        }
        canvas.drawText(value, x(px), y(py), p)
    }

    // Dynamic values are printed on top of the fixed supplied template.
    text(serial.take(8), 260f, 450f, 39f, Paint.Align.CENTER)
    text(date.take(18), 805f, 450f, 20f)
    text(customer.take(65), 120f, 514f, 20f)

    // Table rows: fixed background grid; product values are variable.
    val maxRows = min(rows.size, 18)
    val rowTop = 610f
    val rowBottom = 1690f
    val rowHeight = (rowBottom - rowTop) / 18f
    rows.take(maxRows).forEachIndexed { i, item ->
        val baseline = rowTop + (i + 0.72f) * rowHeight
        text(item.particulars.take(42), 120f, baseline, 17f)
        text(item.qty.take(8), 650f, baseline, 17f, Paint.Align.CENTER)
        text(item.rate.take(12), 775f, baseline, 17f, Paint.Align.CENTER)
        text("%.2f".format(Locale.US, item.amount()), 920f, baseline, 17f, Paint.Align.CENTER)
    }
    val total = rows.sumOf { it.amount() }
    text("%.2f".format(Locale.US, total), 920f, 1745f, 22f, Paint.Align.CENTER)

    doc.finishPage(page)
    val output = java.io.ByteArrayOutputStream()
    doc.writeTo(output)
    doc.close()
    bitmap.recycle()
    return output.toByteArray()
}

fun savePdf(activity: Activity, bytes: ByteArray, fileName: String) {
    val resolver = activity.contentResolver
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
        put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOCUMENTS + "/Rohit Computers")
        }
    }
    val uri = resolver.insert(MediaStore.Files.getContentUri("external"), values)
        ?: throw IllegalStateException("Could not create PDF file")
    resolver.openOutputStream(uri)?.use { it.write(bytes) }
        ?: throw IllegalStateException("Could not write PDF")
    Toast.makeText(activity, "PDF saved in Documents/Rohit Computers", Toast.LENGTH_LONG).show()
}
